# AOS — Acquisition Operation System

Business-independent engines that acquisition applications build on. Each
application supplies its own business rules as policies; AOS never contains them.

This repository currently contains six components: the qualification engine, the
category engine, a polite web fetcher, a page selector, and two web-page parsers
(HTML and robots.txt).

## Qualification (`@avannelli/aos/qualification`)

Source: [`src/qualification/policy.ts`](src/qualification/policy.ts). It is a pure
module: no imports, runtime dependencies, environment access, I/O or database
access.

### What it does

Given a **policy** and an **input**, it computes a priority score and a
qualification verdict, and runs the policy's validation hooks. It knows nothing
about any business. Criteria, weights, thresholds, labels, explanations and
validation all come from the policy.

### Policies belong to the consumer

The consuming application defines a `ScoringPolicy<Input, Key>` (or a
`QualificationPolicy<Input, Key, EvidenceInput>`, which adds evidence
validation) and passes it on each call:

```ts
import { evaluatePolicy, type ScoringPolicy } from "@avannelli/aos/qualification";

const policy: ScoringPolicy<{ open?: "yes" | "no"; seats: number }, "open" | "large"> = {
  policyId: "example.venue",
  version: "v1",
  signals: [
    { key: "open", label: "Open to the public", weight: 0, kind: "observation", requiredCriterion: true },
    { key: "large", label: "Large", weight: 100, kind: "derived" },
  ],
  bandThresholds: { high: 70, medium: 40 },
  bandLabels: { high: "High", medium: "Medium", low: "Low" },
  qualificationLabels: { meets_criteria: "Eligible", unverified: "Check", disqualified: "Ineligible" },
  resolveSignals: (i) => ({ open: i.open ?? "unknown", large: i.seats >= 100 ? "yes" : "no" }),
  explainSignal: (key, state) => `${key}: ${state}`,
  consistencyErrors: (i) => (i.seats < 0 ? ["Seats cannot be negative."] : []),
};

const result = evaluatePolicy(policy, { open: "yes", seats: 120 });
```

Policy hooks must be synchronous, deterministic, trusted code with no I/O.
Business-specific rules, vocabulary and data access must never be added to this
engine. They belong in the consumer's policy. `test/qualification/boundary.test.ts`
enforces this.

### What the result represents

`evaluatePolicy` returns a `ScoreResult`:

- `policyId`, `version`: the identity of the policy that produced it. Persist
  these with any stored score. A behaviour change in a policy must bump its version.
- `score` / `maxScore`: the sum of the weights of criteria observed as `yes`, and
  the sum of all weights. Not assumed to be out of 100.
- `band`: `high` / `medium` / `low` from the policy's inclusive lower thresholds.
  This is **priority only**.
- `qualification`: `disqualified` if any required criterion is `no`;
  otherwise `unverified` if any required criterion is `unknown`; otherwise
  `meets_criteria`. Qualification and priority are independent. A high score
  never overrides a failed or unverified required criterion.
- `disqualifiedBy`, `unverifiedCriteria`: the required criteria responsible.
- `known` / `total`: how many criteria have a definite `yes`/`no`.
- `breakdown`: per criterion, in definition order: key, label, weight, effective
  state, points, `derived` flag and the policy's explanation.

`validatePolicyInput` and `validateQualificationEvidence` return
`{ policyId, version, errors }` from the policy's `consistencyErrors` and
`evidenceErrors` hooks. A score is not evidence approval, and the engine
authorises nothing. The caller remains responsible for gating writes and actions.

### Fails closed

A criterion's state counts only if the policy's resolver returns exactly `"yes"`
or `"no"`. A value that is omitted, misspelled, of the wrong type or otherwise
malformed is `unknown`. It earns no points and can never satisfy a required
criterion.

Exported helpers: `evaluatePolicy`, `validatePolicyInput`,
`validateQualificationEvidence`, `bandFor`, `qualificationFor`, plus the types
`PolicyIdentity`, `SignalState`, `StoredSignalValue`, `ScoreBand`,
`Qualification`, `CriterionDefinition`, `ScoringPolicy`, `QualificationPolicy`,
`SignalResult`, `ScoreResult`, `PolicyValidationResult`.

### Provenance and parity

`policy.ts` was extracted unchanged (byte-identical) from the first consuming
application's isolated engine, where it is covered by an exhaustive parity
oracle. That oracle exercises the application's own business policy, so it does
not live here. Cross-repository parity will be proven when that application
switches to consuming this package: its existing oracle must pass unchanged
against `@avannelli/aos/qualification`. The tests here use synthetic policies only.

## Category engine (`@avannelli/aos/categories`)

Source: [`src/categories/categories.ts`](src/categories/categories.ts). It answers
"is this business the kind the target serves?" with one of three verdicts, each
with a quotable reason, its source and the rule-set id:

- `in_target`: the business's own website confirms it. Or, only for rules that
  opt in with `name.provisional: false`, a usable name or provider category with
  nothing outside the target.
- `wrong_category`: positive evidence of a business outside the target.
- `unclear`: mixed, too little, missing or malformed evidence. A person should look.

It is policy-driven. The consuming application supplies a `CategoryRules`
object: its target, in-scope and out-of-scope name terms (with `exclusive` /
`strong` / `weak` strength), website vocabulary and other trades, and two
thresholds. The engine knows no industry. Business category rules belong to the
consumer, never in AOS.

```ts
import { checkName, checkWebsite, validateCategoryRules } from "@avannelli/aos/categories";

validateCategoryRules(rules);      // { id, errors: [] } when the rules are usable
checkName(rules, { name: "Harbor Bistro", providerCategory: "eating_place" });
checkWebsite(rules, pages, confirmed); // confirmed: { url, what } the caller verified, or null
```

`automatedMayReplace(current, next)` decides whether an automated result may
overwrite a stored one. It never overwrites a person's decision, never lets name or
provider evidence overwrite website evidence, and never lets a website `unclear`
clear name evidence of `wrong_category`. Storing results is the consumer's job.

### Fails closed

- Name and provider evidence is **provisional by default**. If `provisional` is
  omitted, a name or provider category alone yields `unclear`, never `in_target`.
  Only an explicit `provisional: false` opts in.
- Missing or malformed observations never yield `in_target`. That covers blank or
  non-string names (even with the opt-in), non-string provider fields (ignored),
  malformed pages (not read), and malformed website confirmations (ignored).
- Invalid rules are rejected. `validateCategoryRules` reports, for example:
  - a non-boolean `provisional`;
  - unknown or missing strengths;
  - patterns that aren't `RegExp`s or that match empty text;
  - bad thresholds;
  - unknown fields, such as a misspelled `provisonal`.

  `checkName`/`checkWebsite` throw `CategoryRulesError` rather than evaluate
  invalid rules.
- `automatedMayReplace` refuses malformed results and stored sources it does not
  recognise.
- Missing evidence never makes a business `wrong_category` either. That always
  takes a term the rules name as outside the target.

Provenance: extracted from the first consuming application. Its well-formed rules
and inputs give identical results. The one deliberate change is the default.
Previously, omitting `provisional` meant name/provider evidence could produce
`in_target`. Now it must be opted into, and malformed inputs no longer count as
evidence.

## Polite fetcher (`@avannelli/aos/fetch`)

Source: [`src/fetch/fetch.ts`](src/fetch/fetch.ts). `PoliteFetcher` reads public
web pages politely and within limits. For every request it:

- honours robots.txt, read once per origin with the AOS robots parser. A 4xx
  robots.txt means no restrictions, a 5xx skips the site, and a network failure
  marks it unreachable;
- waits at least `perHostDelayMs` between requests to the same host;
- applies per-request timeouts (`robotsTimeoutMs` for robots.txt) and reads at
  most `maxBytes`;
- retries only transient failures (timeouts and connection errors, 429, 5xx), up
  to `maxRetries` times, `retryDelayMs` apart. DNS and TLS errors, 401/403 and
  other 4xx are never retried;
- treats 401/403 as "blocked" (automated access refused) rather than "dead";
- accepts only HTML (a missing content type counts as HTML);
- records each request as a `SourceRecord`. Bodies are returned, never stored.

`page(url)` returns `{ source, html, result }`. `httpsCheck(host)` reports
whether `https://host/` loads with a valid certificate (`true`, `false`, or
`null` when unknown). `fetcher.sources` lists every request in order.

```ts
import { PoliteFetcher } from "@avannelli/aos/fetch";

const fetcher = new PoliteFetcher({
  userAgent: "ExampleBot/1.0 (+https://example.test/bot)", // sent as User-Agent
  robotsAgent: "ExampleBot",                               // matched in robots.txt
  limits: { timeoutMs: 10_000, robotsTimeoutMs: 5_000, maxBytes: 1_500_000, perHostDelayMs: 1_000, retryDelayMs: 2_000, maxRetries: 1 },
  // optional: get (transport), sleep, now: inject for tests or other runtimes
});
```

The crawler's identity and limits are always the consumer's. The constructor
throws `TypeError` when the user agent, robots agent token or any limit is
missing or invalid. AOS embeds no crawler name and no tuning.

`defaultHttpGet` is the real transport: global `fetch`, following redirects,
reading at most `maxBytes`, always decoding as UTF-8. It classifies network
failures as `timeout`, `dns`, `tls` or `connection`. Any `HttpGet` can replace
it. Redirect targets are not re-checked against robots.txt; the requested
origin's rules decide.

## Page selector (`@avannelli/aos/pages`)

Source: [`src/pages/pages.ts`](src/pages/pages.ts). From a site's home page links,
`selectPages(home, policy)` picks the few same-site pages worth reading: at most
one per role, in role order, up to `max`. It is pure: no fetching and no I/O.

```ts
import { DEFAULT_SKIP, selectPages } from "@avannelli/aos/pages";

const pages = selectPages(
  { url: "https://example.test/", links: parsed.links }, // e.g. from @avannelli/aos/html
  {
    roles: [
      { role: "contact", pattern: /contact|reach-us/i },
      { role: "about", pattern: /about|our-story/i },
      { role: "services", pattern: /services/i, prefer: /featured/i },
    ],
    skip: DEFAULT_SKIP,
    max: 4,
  },
); // [{ url, role }, ...]
```

- A link is resolved against the home URL. It counts only if:
  - it is http(s);
  - it is on the same site (`www.` is ignored; other subdomains are different sites);
  - it isn't the home URL or the home path (with any query);
  - it hasn't already been chosen.

  Fragments are stripped; nothing else is canonicalised.
- A role's `pattern` is matched against the link's path, then its text.
- `prefer` puts the links whose `href + " " + text` match first, for that role only;
  ties keep link order.
- `skip` is tested on the raw href. `DEFAULT_SKIP` is a generic filter: documents
  and media, CMS admin/login/cart/checkout/account/feed paths, and `javascript:`,
  `mailto:`, `tel:` and `sms:` links.
- Global and sticky flags are ignored, so patterns carry no state between links or
  calls. Patterns that aren't `RegExp`s are rejected (`TypeError`), never coerced.
  A malformed home URL throws.

Roles, patterns, preferences, the skip rule and the maximum are always the
consumer's. AOS embeds no role vocabulary. Provenance: extracted from the first
consuming application, whose results are identical when it supplies its own rules.

## HTML reader (`@avannelli/aos/html`)

Source: [`src/html/html.ts`](src/html/html.ts). `parseHtml(html: string): ParsedPage`
reads a page body the caller already has, without a DOM and without executing or
fetching anything. It tolerates messy markup. It returns:

- `title` and `siteName` (`og:site_name`), plus `h1`/`h2` `headings`
- `links` (href and text), `buttons` (visible text), and `tels` and `emails`
  from `tel:`/`mailto:` links
- visible `text`, with comments, scripts, styles, `noscript`, `svg`, `template`
  and `iframe` removed
- `structured`: schema.org JSON-LD entities with a `@type` and a name, telephone
  or address (`StructuredBusiness`)

Outputs are capped: 20 headings, 400 links, 50 buttons, 20 phone numbers, 20
emails, 200,000 characters of text, 200 characters per title and structured
value, and 120 characters per link or button text. `decodeEntities` (named,
decimal and hex HTML entities) is exported too. A malformed percent-encoding in a
`tel:`/`mailto:` href throws `URIError`; callers decide how to handle it.

## robots.txt reader (`@avannelli/aos/robots`)

Source: [`src/robots/robots.ts`](src/robots/robots.ts). It does not fetch anything.

- `parseRobots(body, agent): RobotsRules` selects the groups whose `User-agent`
  is a lowercase substring of the caller's `agent` token. Otherwise it uses the
  `*` groups. Matching groups are merged.
- `robotsAllows(rules, path)` applies the longest matching rule, with `Allow`
  winning a tie. It supports the `*` wildcard and the `$` end anchor. Pass the
  path with its query string.

The crawler's identity, fetching, caching and failure policy (for example,
treating an unreachable robots.txt as "skip the site") belong to the consumer.

## Parser parity

`html.ts` and `robots.ts` were extracted unchanged from the first consuming
application. The only edit is one example type name in an `html.ts` doc comment.
`test/html/fixtures.json` and `test/robots/fixtures.json` are outputs recorded
from the original implementation on a generic edge-case corpus, including thrown
errors. The tests replay them exactly.

## Consuming AOS

- ES modules only; Node >= 22.12.
- TypeScript consumers need `moduleResolution` `NodeNext` (or `Bundler`) so
  subpath exports resolve.
- Only the declared subpaths (`@avannelli/aos/qualification`, `/categories`, `/fetch`,
  `/pages`, `/html`, `/robots`) are
  public. There is no root export, and deep imports into `dist/` are blocked by
  `exports`.
- The package is private and is not published to a registry. Consumers install
  a packed tarball (`npm pack`, which cleans and rebuilds `dist/` first) and pin
  it by lockfile integrity.

## Repository conventions

- One module per directory: `src/<module>/` is exposed as
  `@avannelli/aos/<module>` through an explicit `exports` entry, with its tests
  in `test/<module>/`.
- Modules contain no business rules. Business behaviour enters through
  consumer-supplied policies or interfaces. Each module has a boundary test like
  `test/qualification/boundary.test.ts`.
- No runtime dependencies without a clear need. A behaviour change bumps
  `version` and is called out in the commit message.

## Development

```sh
npm install
npm test           # unit + boundary tests
npm run typecheck  # src + tests
npm run build      # emits dist/ (JS + .d.ts)
npm pack           # clean build, then a tarball for consumers
```
