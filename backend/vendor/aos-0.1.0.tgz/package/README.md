# AOS — Acquisition Operation System

Business-independent engines that acquisition applications build on. Each
application supplies its own business rules as policies; AOS never contains them.

This repository currently contains one component: the qualification engine.

## Qualification (`aos/qualification`)

Source: [`src/qualification/policy.ts`](src/qualification/policy.ts). It is a pure
module: no imports, runtime dependencies, environment access, I/O or database
access.

### What it does

Given a **policy** and an **input**, it computes a priority score and a
qualification verdict, and runs the policy's validation hooks. It knows nothing
about any business. Criteria, weights, thresholds, labels, explanations and
validation all come from the policy.

### Policies belong to the consumer

The consuming application defines a `ScoringPolicy<Input, Key>` (or a
`QualificationPolicy<Input, Key, EvidenceInput>`, which adds evidence
validation) and passes it on each call:

```ts
import { evaluatePolicy, type ScoringPolicy } from "aos/qualification";

const policy: ScoringPolicy<{ open?: "yes" | "no"; seats: number }, "open" | "large"> = {
  policyId: "example.venue",
  version: "v1",
  signals: [
    { key: "open", label: "Open to the public", weight: 0, kind: "observation", requiredCriterion: true },
    { key: "large", label: "Large", weight: 100, kind: "derived" },
  ],
  bandThresholds: { high: 70, medium: 40 },
  bandLabels: { high: "High", medium: "Medium", low: "Low" },
  qualificationLabels: { meets_criteria: "Eligible", unverified: "Check", disqualified: "Ineligible" },
  resolveSignals: (i) => ({ open: i.open ?? "unknown", large: i.seats >= 100 ? "yes" : "no" }),
  explainSignal: (key, state) => `${key}: ${state}`,
  consistencyErrors: (i) => (i.seats < 0 ? ["Seats cannot be negative."] : []),
};

const result = evaluatePolicy(policy, { open: "yes", seats: 120 });
```

Policy hooks must be synchronous, deterministic, trusted code with no I/O.
Business-specific rules, vocabulary and data access must never be added to this
engine. They belong in the consumer's policy. `test/qualification/boundary.test.ts`
enforces this.

### What the result represents

`evaluatePolicy` returns a `ScoreResult`:

- `policyId`, `version`: the identity of the policy that produced it. Persist
  these with any stored score. A behaviour change in a policy must bump its version.
- `score` / `maxScore`: the sum of the weights of criteria observed as `yes`, and
  the sum of all weights. Not assumed to be out of 100.
- `band`: `high` / `medium` / `low` from the policy's inclusive lower thresholds.
  This is **priority only**.
- `qualification`: `disqualified` if any required criterion is `no`;
  otherwise `unverified` if any required criterion is `unknown`; otherwise
  `meets_criteria`. Qualification and priority are independent. A high score
  never overrides a failed or unverified required criterion.
- `disqualifiedBy`, `unverifiedCriteria`: the required criteria responsible.
- `known` / `total`: how many criteria have a definite `yes`/`no`.
- `breakdown`: per criterion, in definition order: key, label, weight, effective
  state, points, `derived` flag and the policy's explanation.

`validatePolicyInput` and `validateQualificationEvidence` return
`{ policyId, version, errors }` from the policy's `consistencyErrors` and
`evidenceErrors` hooks. A score is not evidence approval, and the engine
authorises nothing. The caller remains responsible for gating writes and actions.

### Fails closed

A criterion's state counts only if the policy's resolver returns exactly `"yes"`
or `"no"`. A value that is omitted, misspelled, of the wrong type or otherwise
malformed is `unknown`. It earns no points and can never satisfy a required
criterion.

Exported helpers: `evaluatePolicy`, `validatePolicyInput`,
`validateQualificationEvidence`, `bandFor`, `qualificationFor`, plus the types
`PolicyIdentity`, `SignalState`, `StoredSignalValue`, `ScoreBand`,
`Qualification`, `CriterionDefinition`, `ScoringPolicy`, `QualificationPolicy`,
`SignalResult`, `ScoreResult`, `PolicyValidationResult`.

### Provenance and parity

`policy.ts` was extracted unchanged (byte-identical) from the first consuming
application's isolated engine, where it is covered by an exhaustive parity
oracle. That oracle exercises the application's own business policy, so it does
not live here. Cross-repository parity will be proven when that application
switches to consuming this package: its existing oracle must pass unchanged
against `aos/qualification`. The tests here use synthetic policies only.

## Development

```sh
npm install
npm test           # unit + boundary tests
npm run typecheck  # src + tests
npm run build      # emits dist/ (JS + .d.ts)
```

Requires Node >= 22.12.
