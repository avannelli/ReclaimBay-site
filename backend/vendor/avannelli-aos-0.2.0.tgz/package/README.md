# AOS — Acquisition Operation System

Business-independent engines that acquisition applications build on. Each
application supplies its own business rules as policies; AOS never contains them.

This repository currently contains three components: the qualification engine and
two web-page parsers (HTML and robots.txt).

## Qualification (`@avannelli/aos/qualification`)

Source: [`src/qualification/policy.ts`](src/qualification/policy.ts). It is a pure
module: no imports, runtime dependencies, environment access, I/O or database
access.

### What it does

Given a **policy** and an **input**, it computes a priority score and a
qualification verdict, and runs the policy's validation hooks. It knows nothing
about any business. Criteria, weights, thresholds, labels, explanations and
validation all come from the policy.

### Policies belong to the consumer

The consuming application defines a `ScoringPolicy<Input, Key>` (or a
`QualificationPolicy<Input, Key, EvidenceInput>`, which adds evidence
validation) and passes it on each call:

```ts
import { evaluatePolicy, type ScoringPolicy } from "@avannelli/aos/qualification";

const policy: ScoringPolicy<{ open?: "yes" | "no"; seats: number }, "open" | "large"> = {
  policyId: "example.venue",
  version: "v1",
  signals: [
    { key: "open", label: "Open to the public", weight: 0, kind: "observation", requiredCriterion: true },
    { key: "large", label: "Large", weight: 100, kind: "derived" },
  ],
  bandThresholds: { high: 70, medium: 40 },
  bandLabels: { high: "High", medium: "Medium", low: "Low" },
  qualificationLabels: { meets_criteria: "Eligible", unverified: "Check", disqualified: "Ineligible" },
  resolveSignals: (i) => ({ open: i.open ?? "unknown", large: i.seats >= 100 ? "yes" : "no" }),
  explainSignal: (key, state) => `${key}: ${state}`,
  consistencyErrors: (i) => (i.seats < 0 ? ["Seats cannot be negative."] : []),
};

const result = evaluatePolicy(policy, { open: "yes", seats: 120 });
```

Policy hooks must be synchronous, deterministic, trusted code with no I/O.
Business-specific rules, vocabulary and data access must never be added to this
engine. They belong in the consumer's policy. `test/qualification/boundary.test.ts`
enforces this.

### What the result represents

`evaluatePolicy` returns a `ScoreResult`:

- `policyId`, `version`: the identity of the policy that produced it. Persist
  these with any stored score. A behaviour change in a policy must bump its version.
- `score` / `maxScore`: the sum of the weights of criteria observed as `yes`, and
  the sum of all weights. Not assumed to be out of 100.
- `band`: `high` / `medium` / `low` from the policy's inclusive lower thresholds.
  This is **priority only**.
- `qualification`: `disqualified` if any required criterion is `no`;
  otherwise `unverified` if any required criterion is `unknown`; otherwise
  `meets_criteria`. Qualification and priority are independent. A high score
  never overrides a failed or unverified required criterion.
- `disqualifiedBy`, `unverifiedCriteria`: the required criteria responsible.
- `known` / `total`: how many criteria have a definite `yes`/`no`.
- `breakdown`: per criterion, in definition order: key, label, weight, effective
  state, points, `derived` flag and the policy's explanation.

`validatePolicyInput` and `validateQualificationEvidence` return
`{ policyId, version, errors }` from the policy's `consistencyErrors` and
`evidenceErrors` hooks. A score is not evidence approval, and the engine
authorises nothing. The caller remains responsible for gating writes and actions.

### Fails closed

A criterion's state counts only if the policy's resolver returns exactly `"yes"`
or `"no"`. A value that is omitted, misspelled, of the wrong type or otherwise
malformed is `unknown`. It earns no points and can never satisfy a required
criterion.

Exported helpers: `evaluatePolicy`, `validatePolicyInput`,
`validateQualificationEvidence`, `bandFor`, `qualificationFor`, plus the types
`PolicyIdentity`, `SignalState`, `StoredSignalValue`, `ScoreBand`,
`Qualification`, `CriterionDefinition`, `ScoringPolicy`, `QualificationPolicy`,
`SignalResult`, `ScoreResult`, `PolicyValidationResult`.

### Provenance and parity

`policy.ts` was extracted unchanged (byte-identical) from the first consuming
application's isolated engine, where it is covered by an exhaustive parity
oracle. That oracle exercises the application's own business policy, so it does
not live here. Cross-repository parity will be proven when that application
switches to consuming this package: its existing oracle must pass unchanged
against `@avannelli/aos/qualification`. The tests here use synthetic policies only.

## HTML reader (`@avannelli/aos/html`)

Source: [`src/html/html.ts`](src/html/html.ts). `parseHtml(html: string): ParsedPage`
reads a page body the caller already has, without a DOM and without executing or
fetching anything. It tolerates messy markup. It returns:

- `title` and `siteName` (`og:site_name`), plus `h1`/`h2` `headings`
- `links` (href and text), `buttons` (visible text), and `tels` and `emails`
  from `tel:`/`mailto:` links
- visible `text`, with comments, scripts, styles, `noscript`, `svg`, `template`
  and `iframe` removed
- `structured`: schema.org JSON-LD entities with a `@type` and a name, telephone
  or address (`StructuredBusiness`)

Outputs are capped: 20 headings, 400 links, 50 buttons, 20 phone numbers, 20
emails, 200,000 characters of text, 200 characters per title and structured
value, and 120 characters per link or button text. `decodeEntities` (named,
decimal and hex HTML entities) is exported too. A malformed percent-encoding in a
`tel:`/`mailto:` href throws `URIError`; callers decide how to handle it.

## robots.txt reader (`@avannelli/aos/robots`)

Source: [`src/robots/robots.ts`](src/robots/robots.ts). It does not fetch anything.

- `parseRobots(body, agent): RobotsRules` selects the groups whose `User-agent`
  is a lowercase substring of the caller's `agent` token. Otherwise it uses the
  `*` groups. Matching groups are merged.
- `robotsAllows(rules, path)` applies the longest matching rule, with `Allow`
  winning a tie. It supports the `*` wildcard and the `$` end anchor. Pass the
  path with its query string.

The crawler's identity, fetching, caching and failure policy (for example,
treating an unreachable robots.txt as "skip the site") belong to the consumer.

## Parser parity

`html.ts` and `robots.ts` were extracted unchanged from the first consuming
application. The only edit is one example type name in an `html.ts` doc comment.
`test/html/fixtures.json` and `test/robots/fixtures.json` are outputs recorded
from the original implementation on a generic edge-case corpus, including thrown
errors. The tests replay them exactly.

## Consuming AOS

- ES modules only; Node >= 22.12.
- TypeScript consumers need `moduleResolution` `NodeNext` (or `Bundler`) so
  subpath exports resolve.
- Only the declared subpaths (`@avannelli/aos/qualification`, `/html`, `/robots`) are
  public. There is no root export, and deep imports into `dist/` are blocked by
  `exports`.
- The package is private and is not published to a registry. Consumers install
  a packed tarball (`npm pack`, which cleans and rebuilds `dist/` first) and pin
  it by lockfile integrity.

## Repository conventions

- One module per directory: `src/<module>/` is exposed as
  `@avannelli/aos/<module>` through an explicit `exports` entry, with its tests
  in `test/<module>/`.
- Modules contain no business rules. Business behaviour enters through
  consumer-supplied policies or interfaces. Each module has a boundary test like
  `test/qualification/boundary.test.ts`.
- No runtime dependencies without a clear need. A behaviour change bumps
  `version` and is called out in the commit message.

## Development

```sh
npm install
npm test           # unit + boundary tests
npm run typecheck  # src + tests
npm run build      # emits dist/ (JS + .d.ts)
npm pack           # clean build, then a tarball for consumers
```
